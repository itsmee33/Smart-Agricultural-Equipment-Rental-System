/* ============================================================
   FarmRental — Marathi Language Toggle  (v2)
   - Swaps all [data-mr] elements between English ↔ Marathi
   - Handles <option data-mr> select elements correctly
     (span inside option doesn't render — data-mr on the option itself)
   - Handles input/textarea placeholders via [data-mr-ph]
   - Handles <title data-mr>
   - Persists choice in localStorage across pages
   - Smooth fade transition on language switch
   ============================================================ */

(function () {
  'use strict';

  /* ── Apply Marathi ── */
  function applyMarathi() {
    document.querySelectorAll('[data-mr]').forEach(function (el) {
      if (!el.dataset.en) {
        el.dataset.en = el.textContent.trim();
      }
      el.textContent = el.dataset.mr;
    });

    // Placeholders on inputs / textareas
    document.querySelectorAll('[data-mr-ph]').forEach(function (el) {
      if (!el.dataset.enPh) el.dataset.enPh = el.placeholder;
      el.placeholder = el.dataset.mrPh;
    });

    // Page <title>
    var titleEl = document.querySelector('title[data-mr]');
    if (titleEl) {
      if (!titleEl.dataset.en) titleEl.dataset.en = titleEl.textContent.trim();
      document.title = titleEl.dataset.mr;
    }

    document.documentElement.lang = 'mr';
  }

  /* ── Apply English ── */
  function applyEnglish() {
    document.querySelectorAll('[data-mr]').forEach(function (el) {
      if (el.dataset.en) el.textContent = el.dataset.en;
    });

    document.querySelectorAll('[data-mr-ph]').forEach(function (el) {
      if (el.dataset.enPh) el.placeholder = el.dataset.enPh;
    });

    var titleEl = document.querySelector('title[data-mr]');
    if (titleEl && titleEl.dataset.en) {
      document.title = titleEl.dataset.en;
    }

    document.documentElement.lang = 'en';
  }

  /* ── Smooth fade on switch ── */
  function withFade(fn) {
    document.body.style.transition = 'opacity 0.15s ease';
    document.body.style.opacity = '0.65';
    setTimeout(function () {
      fn();
      document.body.style.opacity = '1';
      setTimeout(function () { document.body.style.transition = ''; }, 200);
    }, 110);
  }

  /* ── Update every toggle button on the page ── */
  function syncBtn() {
    document.querySelectorAll('#lang-toggle-btn').forEach(function (btn) {
      if (localStorage.getItem('farmrental_lang') === 'mr') {
        btn.innerHTML = '<span style="font-size:1rem;">🇮🇳</span> English';
        btn.title = 'Switch to English';
      } else {
        btn.innerHTML = '<span style="font-size:1rem;">🇮🇳</span> मराठी';
        btn.title = 'मराठीत बदला';
      }
    });
  }

  /* ── Public toggle (called by onclick) ── */
  window.toggleMarathi = function () {
    var current = localStorage.getItem('farmrental_lang');
    if (current === 'mr') {
      withFade(function () {
        applyEnglish();
        localStorage.setItem('farmrental_lang', 'en');
        syncBtn();
      });
    } else {
      withFade(function () {
        applyMarathi();
        localStorage.setItem('farmrental_lang', 'mr');
        syncBtn();
      });
    }
  };

  /* ── Auto-apply on page load ── */
  document.addEventListener('DOMContentLoaded', function () {
    if (localStorage.getItem('farmrental_lang') === 'mr') {
      applyMarathi();
    }
    syncBtn();
  });
})();
